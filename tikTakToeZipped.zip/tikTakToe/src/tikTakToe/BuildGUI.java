package tikTakToe;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.swing.*;

public class BuildGUI {
	final int MAX_LOGGED=90;
	JFrame window;
	JPanel gameArea;
	JPanel panel,topPanel,miniPanel,microPanel;//Decorative panels
	JLabel playerLabel,winLabelX,winLabelO,turnLabel;
	JTextField pXName,pOName;
	JButton playableSlots[][]=new JButton [3][3];
	JList gameHistory;
	JScrollPane scrollSection,scrollSectionHoriz;
	String[] gameLog;
	JButton restartButton, newButton,exitButton;
	int winCountPX=0,winCountPO=0,gameNumber=1;//Track amount of wins for player one and two
	String playerTurn,startedLast;//Keep track of rather X or O turn

	public BuildGUI() {
		//Determine random start
		Random rand = new Random();
		if(rand.nextInt(1000)%2==0) {
			playerTurn="X";
			startedLast="X";
		}
		else {
			playerTurn="O";
			startedLast="O";
		}
		window= new JFrame();
		window.setTitle("TicTacToe");
		window.setSize(600,400);
		
		buildPanel();
		window.add(panel);
		
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
		}
	private void buildPanel() {
		panel=new JPanel();
		panel.setLayout(new BorderLayout());
		//Create Tic Tac Toe Board
		gameArea= new JPanel();
		gameArea.setLayout(new GridLayout(3,3));
		createGameButtons();
		buildTopPanel();
		buildHistoryPanel();//adds history panel
		buildButtonPanel();//adds buttons
		
		panel.add(topPanel,BorderLayout.NORTH);
		panel.add(gameArea, BorderLayout.CENTER);
	}
	private void buildButtonPanel() {
		miniPanel= new JPanel();
		restartButton=new JButton("Reset Scores");
		newButton= new JButton("New Game");
		exitButton= new JButton("Exit");
		restartButton.addActionListener(new systemButtonListener());
		exitButton.addActionListener(new systemButtonListener());
		newButton.addActionListener(new systemButtonListener());
		miniPanel.setLayout(new GridLayout(1,3));
		miniPanel.add(newButton);
		miniPanel.add(restartButton);
		miniPanel.add(exitButton);
		
		panel.add(miniPanel,BorderLayout.SOUTH);
	}
	private class systemButtonListener implements ActionListener
	{

		public void actionPerformed(ActionEvent e)//What the button does when clicked
		{
			if(e.getSource()==exitButton) {
				System.exit(0);
			}
			else if(e.getSource()==restartButton) {
				//Reset board
				resetBoard();
				//Reset scores
				winCountPX=0;
				winCountPO=0;
				gameNumber=1;
				//Reset game log
				if(playerTurn.equals("X")) {
					gameLog[0]=pXName.getText()+" Starts";
				}
				else if(playerTurn.equals("O")) {
					gameLog[0]=pOName.getText()+" Starts";
				}
				for(int i=1;i<gameLog.length;i++) {
					gameLog[i]="";
				}
				//updateGui
				gameHistory.setListData(gameLog);
				winLabelX.setText("Wins: "+winCountPX); 
				winLabelO.setText("Wins: "+winCountPO);
			}
			else if(e.getSource()==newButton) {
				resetBoard();//only the board needs to be reset in the middle of a game
			}
		}
	}
	private void buildHistoryPanel() {
		miniPanel= new JPanel();
		miniPanel.setBorder(BorderFactory.createTitledBorder("Game Log:"));
		gameLog=new String[MAX_LOGGED];
		gameLog[0]=playerTurn+" Starts";
		gameHistory=new JList(gameLog);
		gameHistory.setVisibleRowCount(10);
		scrollSection= new JScrollPane(gameHistory);
		scrollSectionHoriz= new JScrollPane(scrollSection);
		scrollSectionHoriz.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);//set horixontal scroll
		scrollSection.setPreferredSize(new Dimension(150,200));
		miniPanel.add(scrollSectionHoriz);
		

		panel.add(miniPanel,BorderLayout.EAST);
		
	}
	private void createGameButtons() {
		for(int i=0;i<3;i++) {//Initialize array of JButton objects and add to GUI
			for(int j=0;j<3;j++) {
				playableSlots[i][j]=new JButton("");
				playableSlots[i][j].setBackground(new Color(78, 64, 84));
				playableSlots[i][j].setForeground(new Color(250,250 , 250));
				playableSlots[i][j].addActionListener(new selectButtonListener());
				gameArea.add(playableSlots[i][j]);
			}
		}
	}
	
	private void setGameButton(int row, int column) {//main game logic
		playableSlots[row][column].setText(playerTurn);//Set slot to X or O
		
		//Check if winning move
		if(checkIfWinner(row,column)) {
			if(playerTurn.equals("X")) {
				winCountPX++;
				winLabelX.setText("Wins: "+winCountPX);
				gameLog[gameNumber]="Game "+ gameNumber+":"+pXName.getText()+ " Won";
				JOptionPane.showMessageDialog(null,pXName.getText()+" has won!"); 
			}	
			else if(playerTurn.equals("O")) {
				winCountPO++;
				winLabelO.setText("Wins: "+winCountPO);
				gameLog[gameNumber]="Game "+ gameNumber+":"+pOName.getText()+ " Won";
				JOptionPane.showMessageDialog(null,pOName.getText()+" has won!"); 
			}	
			resetBoard();
			if(startedLast.equals("X"))//If end of round set who gets so start nxt round
				startedLast="O";
			else if(startedLast.equals("O"))
				startedLast="X";
			playerTurn=startedLast;
			gameNumber++;
			gameHistory.setListData(gameLog);
			return;
		}
		if(checkIfEndRound()) {
			JOptionPane.showMessageDialog(null,"The Game has ended in a tie!"); 
			resetBoard();
			gameLog[gameNumber]="Game "+ gameNumber+": Tie";
			if(startedLast.equals("X"))//If end of round set who gets to start next round
				startedLast="O";
			else if(startedLast.equals("O"))
				startedLast="X";
			playerTurn=startedLast;
			gameNumber++;
			gameHistory.setListData(gameLog);
			return;
		}
		
		//Set who's turn is next
		if(playerTurn.equals("X"))
			playerTurn="O";
		else if(playerTurn.equals("O"))
			playerTurn="X";
	}
	private Boolean checkIfWinner(int r,int c) {
		String testedValues[]=new String [3];
		//Test diagonal
		for(int i=0;i<3;i++) {
			testedValues[i]=playableSlots[i][i].getActionCommand();	
		}
		if(testedValues[0].equals(testedValues[1])&&testedValues[1].equals(testedValues[2]))
			if(!testedValues[0].isEmpty())
				return true;
		//Test other diagonal
		testedValues[0]=playableSlots[0][2].getActionCommand();
		testedValues[0]=playableSlots[1][1].getActionCommand();
		testedValues[0]=playableSlots[2][0].getActionCommand();
		if(testedValues[0].equals(testedValues[1])&&testedValues[1].equals(testedValues[2]))
			if(!testedValues[0].isEmpty())
				return true;
		//Test row
		for(int i=0;i<3;i++) {
			testedValues[i]=playableSlots[r][i].getActionCommand();
		}
		if(testedValues[0].equals(testedValues[1])&&testedValues[1].equals(testedValues[2]))
			if(!testedValues[0].isEmpty())
				return true;
		//Test column
		for(int i=0;i<3;i++) {
			testedValues[i]=playableSlots[i][c].getActionCommand();
		}
		if(testedValues[0].equals(testedValues[1])&&testedValues[1].equals(testedValues[2]))
			if(!testedValues[0].isEmpty())
				return true;

		return false;
	}
	private void resetBoard() {
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				playableSlots[i][j].setText("");
			}
		}
	}
	private void buildTopPanel() {
		//Create Top Panel section
		topPanel= new JPanel();
		topPanel.setLayout(new GridLayout(1,2));
		miniPanel= new JPanel();
		miniPanel.setLayout(new GridLayout(2,1));
		miniPanel.setBorder(BorderFactory.createTitledBorder("Players"));
		//For player one section
		microPanel= new JPanel();//Panel containing three fields
		playerLabel= new JLabel("Player 1(X)");
		pXName= new JTextField(10);
		winLabelX= new JLabel("Wins: "+winCountPX);
		microPanel.add(playerLabel);
		microPanel.add(pXName);
		microPanel.add(winLabelX);
		miniPanel.add(microPanel);
		//For Player 2 section
		microPanel= new JPanel();
		playerLabel= new JLabel("Player 2(O)");
		pOName= new JTextField(10);
		winLabelO= new JLabel("Wins: "+winCountPO);
		microPanel.add(playerLabel);
		microPanel.add(pOName);
		microPanel.add(winLabelO);
		miniPanel.add(microPanel);
		topPanel.add(miniPanel);//Add players to section
		//For turn section
		miniPanel=new JPanel();
		miniPanel.setBorder(BorderFactory.createTitledBorder("Turn"));
		turnLabel= new JLabel(playerTurn+"'s Turn");
		miniPanel.add(turnLabel);
		topPanel.add(miniPanel);
	}
	private Boolean checkIfEndRound() {
		String checkedItem;
		//Is end of round if there is no blank slots left
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				checkedItem=playableSlots[i][j].getActionCommand();
				if(checkedItem.isEmpty())
					return false;
			}
		}
		return true;
	}
	private void setTurnLabel() {
		if(playerTurn.equals("X")) {
			turnLabel.setText(pXName.getText()+"'s Turn");
		}
		else if(playerTurn.equals("O")) {
			turnLabel.setText(pOName.getText()+"'s Turn");
		}
	}
	private class selectButtonListener implements ActionListener
	{

		public void actionPerformed(ActionEvent e)//What the button does when clicked
		{
			if(gameNumber==1) {//Stop user from not entering name
				
				if(pXName.getText().isBlank()||pOName.getText().isBlank()) {//Force PLayers to enter name
					JOptionPane.showMessageDialog(null,"PLEASE enter names before beginning! Then press Reset Scores.");
					
					
					return;
				}
			}
			String labelOnButton=e.getActionCommand();
			if(labelOnButton.isEmpty()) {//Only update logic if spot is not taken
				for(int i=0;i<3;i++) {
					for(int j=0;j<3;j++) {
						if(e.getSource()==playableSlots[i][j]) {
							setGameButton(i,j);
							setTurnLabel();
							return;
						}
					}
				}
			}
			
		}
	}
	
}
