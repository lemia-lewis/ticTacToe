package tikTakToe;
import javax.swing.*;
import java.awt.*;

public class tikTakToe {
	//Panels and sections for GUI
	JFrame window;


	public static void main(String[] args) {

		new BuildGUI();



	}

}
